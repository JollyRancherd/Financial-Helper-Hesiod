import { useState } from "react";
import { Loader2, LockKeyhole, ScanFace, UserRound } from "lucide-react";
import { useLogin, useRegister } from "@/hooks/use-auth";

export default function AuthPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const login = useLogin();
  const register = useRegister();
  const isBusy = login.isPending || register.isPending;
  const error = login.error?.message || register.error?.message;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = { username, password };
    if (mode === "login") await login.mutateAsync(payload);
    else await register.mutateAsync(payload);
  };

  return (
    <div className="min-h-screen bg-background px-4 py-10 flex items-center justify-center">
      <div className="w-full max-w-md glass-panel p-6 sm:p-8 space-y-6">
        <div className="text-center space-y-3">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <LockKeyhole className="w-7 h-7 text-primary" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold tracking-wide">Budget Login</h1>
            <p className="text-sm text-muted-foreground mt-2">Your data can now stay private and sync across your iPhone and iPad when you use the same deployed app and account.</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 bg-card-soft rounded-xl p-1 border border-white/5">
          <button className={`px-3 py-2 rounded-lg text-sm font-semibold ${mode === "login" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`} onClick={() => setMode("login")}>Log in</button>
          <button className={`px-3 py-2 rounded-lg text-sm font-semibold ${mode === "register" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`} onClick={() => setMode("register")}>Create account</button>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <label className="block space-y-2">
            <span className="text-sm font-medium text-foreground">Username</span>
            <div className="flex items-center gap-2 border border-border rounded-xl px-3 py-3 bg-background/70">
              <UserRound className="w-4 h-4 text-muted-foreground" />
              <input className="bg-transparent outline-none w-full text-sm" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username webauthn" placeholder="michael" />
            </div>
          </label>

          <label className="block space-y-2">
            <span className="text-sm font-medium text-foreground">Password</span>
            <div className="flex items-center gap-2 border border-border rounded-xl px-3 py-3 bg-background/70">
              <LockKeyhole className="w-4 h-4 text-muted-foreground" />
              <input type="password" className="bg-transparent outline-none w-full text-sm" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "login" ? "current-password webauthn" : "new-password webauthn"} placeholder="At least 6 characters" />
            </div>
          </label>

          {error ? <div className="text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-3 py-2">{error}</div> : null}

          <button type="submit" disabled={isBusy} className="w-full rounded-xl bg-primary text-primary-foreground font-semibold py-3 flex items-center justify-center gap-2 disabled:opacity-70">
            {isBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <LockKeyhole className="w-4 h-4" />}
            {mode === "login" ? "Log in" : "Create account"}
          </button>
        </form>

        <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2 font-semibold text-foreground mb-2"><ScanFace className="w-4 h-4 text-primary" /> Fast login note</div>
          Safari/iPhone/iPad can usually save your password in iCloud Keychain, then autofill it with Face ID. True passkeys/WebAuthn are not wired into this version yet.
        </div>
      </div>
    </div>
  );
}
